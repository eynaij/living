App({
  globalData: {
    lastResult: null,
  },
});
